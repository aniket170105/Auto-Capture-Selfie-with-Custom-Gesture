# smile detect > 2021-10-21 9:09pm
https://universe.roboflow.com/chengzhigang/smile-detect

Provided by a Roboflow user
License: CC BY 4.0

